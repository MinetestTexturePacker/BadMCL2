mcl_util = {}

function mcl_util.set_inventory_formspec(player, formspec)
end

function mcl_util.register_button(player,str1, str2)
end