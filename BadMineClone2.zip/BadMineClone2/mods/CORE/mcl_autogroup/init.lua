mcl_autogroup = {}

function mcl_autogroup.set_inventory_formspec(player, formspec)
end

function mcl_autogroup.register_button(player,str1, str2)
end