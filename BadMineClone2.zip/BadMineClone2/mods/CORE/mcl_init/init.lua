mcl_init = {}

function mcl_init.set_inventory_formspec(player, formspec)
end

function mcl_init.register_button(player,str1, str2)
end