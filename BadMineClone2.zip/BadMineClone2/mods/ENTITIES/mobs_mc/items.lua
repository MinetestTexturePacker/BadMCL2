-- shears
minetest.register_tool("mobs_mc:shears", {
	description = "Shears",
	inventory_image = "mobs_mc_shears.png",
})

minetest.register_craft({
	output = 'mobs_mc:shears',
	recipe = {
		{'','default:steel_ingot'},
		{'default:steel_ingot','default:stick'},
	}
})

-- drop items
minetest.register_craftitem("mobs_mc:flesh", {
	description = "Flesh",
	inventory_image = "mobs_mc_flesh.png",
	on_use = minetest.item_eat(2),
})

minetest.register_craftitem("mobs_mc:rotten_flesh", {
	description = "Rotten Flesh",
	inventory_image = "mobs_mc_rotten_flesh.png",
	on_use = minetest.item_eat(1),
})

-- food
minetest.register_craftitem("mobs_mc:meat", {
	description = "Cooked Meat",
	inventory_image = "mobs_mc_meat.png",
	on_use = minetest.item_eat(4),
})

minetest.register_craft({
	type = "cooking",
	output = "mobs_mc:meat",
	recipe = "mobs_mc:flesh",
})

-- spawn-eggs
minetest.register_craftitem("mobs_mc:zombie_spawn_egg", {
	description = "Zombie spawn-egg",
	inventory_image = "mobs_mc_egg_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			mobs_mc.spawn(p, 1, "mobs_mc:zombie", 1, 1)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,

})

minetest.register_craftitem("mobs_mc:ghost_spawn_egg", {
	description = "Ghost spawn-egg",
	inventory_image = "mobs_mc_egg_ghost.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+0.5
			mobs_mc.spawn(p, 1, "mobs_mc:ghost", 1, 1)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,

})

minetest.register_craftitem("mobs_mc:sheep_spawn_egg", {
	description = "Sheep spawn-egg",
	inventory_image = "mobs_mc_egg_sheep.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+0.5
			mobs_mc.spawn(p, 1, "mobs_mc:sheep", 1, 1)
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,

})
