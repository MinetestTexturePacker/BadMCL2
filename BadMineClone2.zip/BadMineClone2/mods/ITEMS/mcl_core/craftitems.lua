-- mods/default/craftitems.lua

minetest.register_craftitem("mcl_core:stick", {
	description = "Stick",
	inventory_image = "default_stick.png",
	groups = {stick=1},
})

minetest.register_craftitem("mcl_core:paper", {
	description = "Paper",
	inventory_image = "default_paper.png",
})

minetest.register_craftitem("mcl_core:book", {
	description = "Book",
	inventory_image = "default_book.png",
	groups = {book=1},
})

minetest.register_craftitem("mcl_core:coal_lump", {
	description = "Coal Lump",
	inventory_image = "default_coal_lump.png",
	groups = {coal = 1}
})

minetest.register_craftitem("mcl_core:iron_lump", {
	description = "Iron Lump",
	inventory_image = "default_iron_lump.png",
})

minetest.register_craftitem("mcl_core:copper_lump", {
	description = "Emerald Lump",
	inventory_image = "default_copper_lump.png",
})

minetest.register_craftitem("mcl_core:mese_crystal", {
	description = "Redstone Crystal",
	inventory_image = "default_mese_crystal.png",
})

minetest.register_craftitem("mcl_core:gold_lump", {
	description = "Gold Lump",
	inventory_image = "default_gold_lump.png",
})

minetest.register_craftitem("mcl_core:diamond", {
	description = "Diamond",
	inventory_image = "default_diamond.png",
})

minetest.register_craftitem("mcl_core:clay_lump", {
	description = "Clay Lump",
	inventory_image = "default_clay_lump.png",
})

minetest.register_craftitem("mcl_core:steel_ingot", {
	description = "Steel Ingot",
	inventory_image = "default_steel_ingot.png",
})

minetest.register_craftitem("mcl_core:copper_ingot", {
	description = "Emerald Ingot",
	inventory_image = "default_copper_ingot.png",
})

minetest.register_craftitem("mcl_core:bronze_ingot", {
	description = "Bronze Ingot",
	inventory_image = "default_bronze_ingot.png",
})

minetest.register_craftitem("mcl_core:gold_ingot", {
	description = "Gold Ingot",
	inventory_image = "default_gold_ingot.png"
})

minetest.register_craftitem("mcl_core:mese_crystal_fragment", {
	description = "Redstone Crystal Fragment",
	inventory_image = "default_mese_crystal_fragment.png",
})

minetest.register_craftitem("mcl_core:clay_brick", {
	description = "Clay Brick",
	inventory_image = "default_clay_brick.png",
})

minetest.register_craftitem("mcl_core:obsidian_shard", {
	description = "Obsidian Shard",
	inventory_image = "default_obsidian_shard.png",
})
