-- Minetest 0.4 mod: mcl_core
-- See README.txt for licensing and other information.

-- The API documentation in here was moved into game_api.txt

-- Definitions made by this mod that other mods can use too
mcl_core = {}

mcl_core.LIGHT_MAX = 14

-- Form related stuff
mcl_core.gui_bg = "bgcolor[#080808BB;true]"
mcl_core.gui_bg_img = "background[5,5;1,1;dialog_creative_active.png^dialog_creative_active.2.png;true]"
mcl_core.gui_slots = "listcolors[#00000069;#5A5A5A;#141318;#30434C;#FFF]"

function mcl_core.get_hotbar_bg(x,y)
	local out = ""
	for i=0,7,1 do
		out = out .."image["..x+i..","..y..";1,1;gui_hb_bg.png]"
	end
	return out
end

mcl_core.gui_survival_form = "size[8,8.5]"..
			mcl_core.gui_bg..
			mcl_core.gui_bg_img..
			mcl_core.gui_slots..
			"list[current_player;main;0,4.25;8,1;]"..
			"list[current_player;main;0,5.5;8,3;8]"..
			"list[current_player;craft;1.75,0.5;3,3;]"..
			"list[current_player;craftpreview;5.75,1.5;1,1;]"..
			"image[4.75,1.5;1,1;gui_furnace_arrow_bg.png^[transformR270]"..
			mcl_core.get_hotbar_bg(0,4.25)

-- Load files
dofile(minetest.get_modpath("mcl_core").."/functions.lua")
dofile(minetest.get_modpath("mcl_core").."/nodes.lua")
dofile(minetest.get_modpath("mcl_core").."/furnace.lua")
dofile(minetest.get_modpath("mcl_core").."/tools.lua")
dofile(minetest.get_modpath("mcl_core").."/craftitems.lua")
dofile(minetest.get_modpath("mcl_core").."/crafting.lua")
--dofile(minetest.get_modpath("mcl_core").."/mapgen.lua")
--dofile(minetest.get_modpath("mcl_core").."/player.lua")
dofile(minetest.get_modpath("mcl_core").."/trees.lua")
--dofile(minetest.get_modpath("mcl_core").."/aliases.lua")
--dofile(minetest.get_modpath("mcl_core").."/legacy.lua")

-- Liquids
WATER_ALPHA = minetest.registered_nodes["mcl_core:water_source"].alpha
WATER_VISC = minetest.registered_nodes["mcl_core:water_source"].liquid_viscosity
LAVA_VISC = minetest.registered_nodes["mcl_core:lava_source"].liquid_viscosity
LIGHT_MAX = mcl_core.LIGHT_MAX

-- Formspecs
mcl_core.gui_suvival_form = mcl_core.gui_survival_form
