-- mods/mcl_core/crafting.lua

minetest.register_craft({
	output = 'mcl_core:wood 4',
	recipe = {
		{'mcl_core:tree'},
	}
})

minetest.register_craft({
	output = 'mcl_core:junglewood 4',
	recipe = {
		{'mcl_core:jungletree'},
	}
})

minetest.register_craft({
	output = 'mcl_core:pinewood 4',
	recipe = {
		{'mcl_core:pinetree'},
	}
})

minetest.register_craft({
	output = 'mcl_core:stick 4',
	recipe = {
		{'group:wood'},
	}
})

minetest.register_craft({
	output = 'mcl_core:fence_wood 2',
	recipe = {
		{'group:stick', 'group:stick', 'group:stick'},
		{'group:stick', 'group:stick', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:sign_wall',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'group:wood', 'group:wood', 'group:wood'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:torch 4',
	recipe = {
		{'mcl_core:coal_lump'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:pick_wood',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:pick_stone',
	recipe = {
		{'group:stone', 'group:stone', 'group:stone'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:pick_steel',
	recipe = {
		{'mcl_core:steel_ingot', 'mcl_core:steel_ingot', 'mcl_core:steel_ingot'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:pick_bronze',
	recipe = {
		{'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:pick_mese',
	recipe = {
		{'mcl_core:mese_crystal', 'mcl_core:mese_crystal', 'mcl_core:mese_crystal'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:pick_diamond',
	recipe = {
		{'mcl_core:diamond', 'mcl_core:diamond', 'mcl_core:diamond'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:shovel_wood',
	recipe = {
		{'group:wood'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:shovel_stone',
	recipe = {
		{'group:stone'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:shovel_steel',
	recipe = {
		{'mcl_core:steel_ingot'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:shovel_bronze',
	recipe = {
		{'mcl_core:bronze_ingot'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:shovel_mese',
	recipe = {
		{'mcl_core:mese_crystal'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:shovel_diamond',
	recipe = {
		{'mcl_core:diamond'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_wood',
	recipe = {
		{'group:wood', 'group:wood'},
		{'group:wood', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_stone',
	recipe = {
		{'group:stone', 'group:stone'},
		{'group:stone', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_steel',
	recipe = {
		{'mcl_core:steel_ingot', 'mcl_core:steel_ingot'},
		{'mcl_core:steel_ingot', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_bronze',
	recipe = {
		{'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot'},
		{'mcl_core:bronze_ingot', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_mese',
	recipe = {
		{'mcl_core:mese_crystal', 'mcl_core:mese_crystal'},
		{'mcl_core:mese_crystal', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_diamond',
	recipe = {
		{'mcl_core:diamond', 'mcl_core:diamond'},
		{'mcl_core:diamond', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_wood',
	recipe = {
		{'group:wood', 'group:wood'},
		{'group:stick', 'group:wood'},
		{'group:stick',''},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_stone',
	recipe = {
		{'group:stone', 'group:stone'},
		{'group:stick', 'group:stone'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_steel',
	recipe = {
		{'mcl_core:steel_ingot', 'mcl_core:steel_ingot'},
		{'group:stick', 'mcl_core:steel_ingot'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_bronze',
	recipe = {
		{'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot'},
		{'group:stick', 'mcl_core:bronze_ingot'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_mese',
	recipe = {
		{'mcl_core:mese_crystal', 'mcl_core:mese_crystal'},
		{'group:stick', 'mcl_core:mese_crystal'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:axe_diamond',
	recipe = {
		{'mcl_core:diamond', 'mcl_core:diamond'},
		{'group:stick', 'mcl_core:diamond'},
		{'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'mcl_core:sword_wood',
	recipe = {
		{'group:wood'},
		{'group:wood'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:sword_stone',
	recipe = {
		{'group:stone'},
		{'group:stone'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:sword_steel',
	recipe = {
		{'mcl_core:steel_ingot'},
		{'mcl_core:steel_ingot'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:sword_bronze',
	recipe = {
		{'mcl_core:bronze_ingot'},
		{'mcl_core:bronze_ingot'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:sword_mese',
	recipe = {
		{'mcl_core:mese_crystal'},
		{'mcl_core:mese_crystal'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:sword_diamond',
	recipe = {
		{'mcl_core:diamond'},
		{'mcl_core:diamond'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:rail 15',
	recipe = {
		{'mcl_core:steel_ingot', '', 'mcl_core:steel_ingot'},
		{'mcl_core:steel_ingot', 'group:stick', 'mcl_core:steel_ingot'},
		{'mcl_core:steel_ingot', '', 'mcl_core:steel_ingot'},
	}
})

minetest.register_craft({
	output = 'mcl_core:chest',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'group:wood', '', 'group:wood'},
		{'group:wood', 'group:wood', 'group:wood'},
	}
})

minetest.register_craft({
	output = 'mcl_core:chest_locked',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'group:wood', 'mcl_core:steel_ingot', 'group:wood'},
		{'group:wood', 'group:wood', 'group:wood'},
	}
})

minetest.register_craft({
	output = 'mcl_core:furnace',
	recipe = {
		{'group:stone', 'group:stone', 'group:stone'},
		{'group:stone', '', 'group:stone'},
		{'group:stone', 'group:stone', 'group:stone'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = "mcl_core:bronze_ingot",
	recipe = {"mcl_core:steel_ingot", "mcl_core:copper_ingot"},
})

minetest.register_craft({
	output = 'mcl_core:coalblock',
	recipe = {
		{'mcl_core:coal_lump', 'mcl_core:coal_lump', 'mcl_core:coal_lump'},
		{'mcl_core:coal_lump', 'mcl_core:coal_lump', 'mcl_core:coal_lump'},
		{'mcl_core:coal_lump', 'mcl_core:coal_lump', 'mcl_core:coal_lump'},
	}
})

minetest.register_craft({
	output = 'mcl_core:coal_lump 9',
	recipe = {
		{'mcl_core:coalblock'},
	}
})

minetest.register_craft({
	output = 'mcl_core:steelblock',
	recipe = {
		{'mcl_core:steel_ingot', 'mcl_core:steel_ingot', 'mcl_core:steel_ingot'},
		{'mcl_core:steel_ingot', 'mcl_core:steel_ingot', 'mcl_core:steel_ingot'},
		{'mcl_core:steel_ingot', 'mcl_core:steel_ingot', 'mcl_core:steel_ingot'},
	}
})

minetest.register_craft({
	output = 'mcl_core:steel_ingot 9',
	recipe = {
		{'mcl_core:steelblock'},
	}
})

minetest.register_craft({
	output = 'mcl_core:copperblock',
	recipe = {
		{'mcl_core:copper_ingot', 'mcl_core:copper_ingot', 'mcl_core:copper_ingot'},
		{'mcl_core:copper_ingot', 'mcl_core:copper_ingot', 'mcl_core:copper_ingot'},
		{'mcl_core:copper_ingot', 'mcl_core:copper_ingot', 'mcl_core:copper_ingot'},
	}
})

minetest.register_craft({
	output = 'mcl_core:copper_ingot 9',
	recipe = {
		{'mcl_core:copperblock'},
	}
})

minetest.register_craft({
	output = 'mcl_core:bronzeblock',
	recipe = {
		{'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot'},
		{'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot'},
		{'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot', 'mcl_core:bronze_ingot'},
	}
})

minetest.register_craft({
	output = 'mcl_core:bronze_ingot 9',
	recipe = {
		{'mcl_core:bronzeblock'},
	}
})

minetest.register_craft({
	output = 'mcl_core:goldblock',
	recipe = {
		{'mcl_core:gold_ingot', 'mcl_core:gold_ingot', 'mcl_core:gold_ingot'},
		{'mcl_core:gold_ingot', 'mcl_core:gold_ingot', 'mcl_core:gold_ingot'},
		{'mcl_core:gold_ingot', 'mcl_core:gold_ingot', 'mcl_core:gold_ingot'},
	}
})

minetest.register_craft({
	output = 'mcl_core:gold_ingot 9',
	recipe = {
		{'mcl_core:goldblock'},
	}
})

minetest.register_craft({
	output = 'mcl_core:diamondblock',
	recipe = {
		{'mcl_core:diamond', 'mcl_core:diamond', 'mcl_core:diamond'},
		{'mcl_core:diamond', 'mcl_core:diamond', 'mcl_core:diamond'},
		{'mcl_core:diamond', 'mcl_core:diamond', 'mcl_core:diamond'},
	}
})

minetest.register_craft({
	output = 'mcl_core:diamond 9',
	recipe = {
		{'mcl_core:diamondblock'},
	}
})

minetest.register_craft({
	output = 'mcl_core:sandstone',
	recipe = {
		{'group:sand', 'group:sand'},
		{'group:sand', 'group:sand'},
	}
})

minetest.register_craft({
	output = 'mcl_core:sand 4',
	recipe = {
		{'mcl_core:sandstone'},
	}
})

minetest.register_craft({
	output = 'mcl_core:sandstonebrick 4',
	recipe = {
		{'mcl_core:sandstone', 'mcl_core:sandstone'},
		{'mcl_core:sandstone', 'mcl_core:sandstone'},
	}
})

minetest.register_craft({
	output = 'mcl_core:clay',
	recipe = {
		{'mcl_core:clay_lump', 'mcl_core:clay_lump'},
		{'mcl_core:clay_lump', 'mcl_core:clay_lump'},
	}
})

minetest.register_craft({
	output = 'mcl_core:brick',
	recipe = {
		{'mcl_core:clay_brick', 'mcl_core:clay_brick'},
		{'mcl_core:clay_brick', 'mcl_core:clay_brick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:clay_brick 4',
	recipe = {
		{'mcl_core:brick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:paper',
	recipe = {
		{'mcl_core:papyrus', 'mcl_core:papyrus', 'mcl_core:papyrus'},
	}
})

minetest.register_craft({
	output = 'mcl_core:book',
	recipe = {
		{'mcl_core:paper'},
		{'mcl_core:paper'},
		{'mcl_core:paper'},
	}
})

minetest.register_craft({
	output = 'mcl_core:bookshelf',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'mcl_core:book', 'mcl_core:book', 'mcl_core:book'},
		{'group:wood', 'group:wood', 'group:wood'},
	}
})

minetest.register_craft({
	output = 'mcl_core:ladder',
	recipe = {
		{'group:stick', '', 'group:stick'},
		{'group:stick', 'group:stick', 'group:stick'},
		{'group:stick', '', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'mcl_core:mese',
	recipe = {
		{'mcl_core:mese_crystal', 'mcl_core:mese_crystal', 'mcl_core:mese_crystal'},
		{'mcl_core:mese_crystal', 'mcl_core:mese_crystal', 'mcl_core:mese_crystal'},
		{'mcl_core:mese_crystal', 'mcl_core:mese_crystal', 'mcl_core:mese_crystal'},
	}
})

minetest.register_craft({
	output = 'mcl_core:mese_crystal 9',
	recipe = {
		{'mcl_core:mese'},
	}
})

minetest.register_craft({
	output = 'mcl_core:mese_crystal_fragment 9',
	recipe = {
		{'mcl_core:mese_crystal'},
	}
})

minetest.register_craft({
	output = 'mcl_core:meselamp 1',
	recipe = {
		{'', 'mcl_core:mese_crystal',''},
		{'mcl_core:mese_crystal', 'mcl_core:glass', 'mcl_core:mese_crystal'},
	}
})

minetest.register_craft({
	output = 'mcl_core:obsidian_shard 9',
	recipe = {
		{'mcl_core:obsidian'}
	}
})

minetest.register_craft({
	output = 'mcl_core:obsidian',
	recipe = {
		{'mcl_core:obsidian_shard', 'mcl_core:obsidian_shard', 'mcl_core:obsidian_shard'},
		{'mcl_core:obsidian_shard', 'mcl_core:obsidian_shard', 'mcl_core:obsidian_shard'},
		{'mcl_core:obsidian_shard', 'mcl_core:obsidian_shard', 'mcl_core:obsidian_shard'},
	}
})

minetest.register_craft({
	output = 'mcl_core:obsidianbrick 4',
	recipe = {
		{'mcl_core:obsidian', 'mcl_core:obsidian'},
		{'mcl_core:obsidian', 'mcl_core:obsidian'}
	}
})

minetest.register_craft({
	output = 'mcl_core:stonebrick 4',
	recipe = {
		{'mcl_core:stone', 'mcl_core:stone'},
		{'mcl_core:stone', 'mcl_core:stone'},
	}
})

minetest.register_craft({
	output = 'mcl_core:desert_stonebrick 4',
	recipe = {
		{'mcl_core:desert_stone', 'mcl_core:desert_stone'},
		{'mcl_core:desert_stone', 'mcl_core:desert_stone'},
	}
})

minetest.register_craft({
	output = 'mcl_core:snowblock',
	recipe = {
		{'mcl_core:snow', 'mcl_core:snow', 'mcl_core:snow'},
		{'mcl_core:snow', 'mcl_core:snow', 'mcl_core:snow'},
		{'mcl_core:snow', 'mcl_core:snow', 'mcl_core:snow'},
	}
})

minetest.register_craft({
	output = 'mcl_core:snow 9',
	recipe = {
		{'mcl_core:snowblock'},
	}
})

--
-- Crafting (tool repair)
--
minetest.register_craft({
	type = "toolrepair",
	additional_wear = -0.02,
})

--
-- Cooking recipes
--

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:glass",
	recipe = "group:sand",
})

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:obsidian_glass",
	recipe = "mcl_core:obsidian_shard",
})

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:stone",
	recipe = "mcl_core:cobble",
})

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:stone",
	recipe = "mcl_core:mossycobble",
})

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:desert_stone",
	recipe = "mcl_core:desert_cobble",
})

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:steel_ingot",
	recipe = "mcl_core:iron_lump",
})

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:copper_ingot",
	recipe = "mcl_core:copper_lump",
})

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:gold_ingot",
	recipe = "mcl_core:gold_lump",
})

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:clay_brick",
	recipe = "mcl_core:clay_lump",
})

--
-- Fuels
--

minetest.register_craft({
	type = "fuel",
	recipe = "group:tree",
	burntime = 30,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:junglegrass",
	burntime = 2,
})

minetest.register_craft({
	type = "fuel",
	recipe = "group:leaves",
	burntime = 1,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:cactus",
	burntime = 15,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:papyrus",
	burntime = 1,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:bookshelf",
	burntime = 30,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:fence_wood",
	burntime = 15,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:ladder",
	burntime = 5,
})

minetest.register_craft({
	type = "fuel",
	recipe = "group:wood",
	burntime = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:lava_source",
	burntime = 60,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:torch",
	burntime = 4,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:sign_wall",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:chest",
	burntime = 30,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:chest_locked",
	burntime = 30,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:nyancat",
	burntime = 1,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:nyancat_rainbow",
	burntime = 1,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:sapling",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:apple",
	burntime = 3,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:coal_lump",
	burntime = 40,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:coalblock",
	burntime = 370,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:junglesapling",
	burntime = 10,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:grass_1",
	burntime = 2,
})

minetest.register_craft({
	type = "fuel",
	recipe = "mcl_core:pine_sapling",
	burntime = 10,
})

