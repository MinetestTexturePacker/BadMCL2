-- Minetest 0.4 mod: mcl_potions
-- See README.txt for licensing and other information.

local mcl_potions_shelf_formspec =
	"size[8,7;]"..
	mcl_core.gui_bg..
	mcl_core.gui_bg_img..
	mcl_core.gui_slots..
	"list[context;mcl_potions;0,0.3;8,2;]"..
	"list[current_player;main;0,2.85;8,1;]"..
	"list[current_player;main;0,4.08;8,3;8]"..
	mcl_core.get_hotbar_bg(0,2.85)

minetest.register_node("mcl_potions:shelf", {
	description = "Potion shelf",
	tiles = {"default_wood.png", "default_wood.png", "default_wood.png^mcl_potions_shelf.png"},
	is_ground_content = false,
	groups = {choppy=3,oddly_breakable_by_hand=2,flammable=3},
	sounds = mcl_core.node_sound_wood_mcl_cores(),

	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", mcl_potions_shelf_formspec)
		local inv = meta:get_inventory()
		inv:set_size("mcl_potions", 8*2)
	end,
	can_dig = function(pos,player)
		local meta = minetest.get_meta(pos);
		local inv = meta:get_inventory()
		return inv:is_empty("mcl_potions")
	end,

	allow_metadata_inventory_put = function(pos, listname, index, stack, player)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		local to_stack = inv:get_stack(listname, index)
		if listname == "mcl_potions" then
			if minetest.get_item_group(stack:get_name(), "vessel") ~= 0
					and to_stack:is_empty() then
				return 1
			else
				return 0
			end
		end
	end,

	allow_metadata_inventory_move = function(pos, from_list, from_index, to_list, to_index, count, player)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		local stack = inv:get_stack(from_list, from_index)
		local to_stack = inv:get_stack(to_list, to_index)
		if to_list == "mcl_potions" then
			if minetest.get_item_group(stack:get_name(), "vessel") ~= 0 
					and to_stack:is_empty() then
				return 1
			else
				return 0
			end
		end
	end,

	on_metadata_inventory_move = function(pos, from_list, from_index, to_list, to_index, count, player)
		minetest.log("action", player:get_player_name()..
			   " moves stuff in mcl_potions shelf at "..minetest.pos_to_string(pos))
	end,
	on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
			   " moves stuff to mcl_potions shelf at "..minetest.pos_to_string(pos))
	end,
	on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
			   " takes stuff from mcl_potions shelf at "..minetest.pos_to_string(pos))
	end,
})

minetest.register_craft({
	output = 'mcl_potions:shelf',
	recipe = {
		{'group:wood', 'group:wood', 'group:wood'},
		{'group:vessel', 'group:vessel', 'group:vessel'},
		{'group:wood', 'group:wood', 'group:wood'},
	}
})

minetest.register_node("mcl_potions:potion_bottle", {
	description = "Potion Bottle",
	drawtype = "plantlike",
	tiles = {"mcl_potions_potion_bottle.png"},
	inventory_image = "mcl_potions_potion_bottle.png",
	wield_image = "mcl_potions_potion_bottle.png",
	paramtype = "light",
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.25, -0.5, -0.25, 0.25, 0.4, 0.25}
	},
	groups = {vessel=1,dig_immediate=3,attached_node=1},
	sounds = mcl_core.node_sound_glass_mcl_cores(),
})

minetest.register_craft( {
	output = "mcl_potions:potion_bottle 10",
	recipe = {
		{ "mcl_core:glass", "", "mcl_core:glass" },
		{ "mcl_core:glass", "", "mcl_core:glass" },
		{ "", "mcl_core:glass", "" }
	}
})

minetest.register_node("mcl_potions:potion_drinkable", {
	description = "Drinkable Potion",
	drawtype = "plantlike",
	tiles = {"mcl_potions_potion_drinkable.png"},
	inventory_image = "mcl_potions_potion_drinkable.png",
	wield_image = "mcl_potions_potion_drinkable.png",
	paramtype = "light",
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.25, -0.5, -0.25, 0.25, 0.4, 0.25}
	},
	groups = {vessel=1,dig_immediate=3,attached_node=1},
	sounds = mcl_core.node_sound_glass_mcl_cores(),
})

minetest.register_craft( {
	output = "mcl_potions:potion_drinkable 14",
	recipe = {
		{ "mcl_core:glass", "", "mcl_core:glass" },
		{ "mcl_core:glass", "", "mcl_core:glass" },
		{ "mcl_core:glass", "mcl_core:glass", "mcl_core:glass" }
	}
})

minetest.register_node("mcl_potions:potion_splash", {
	description = "Splash Potion",
	drawtype = "plantlike",
	tiles = {"mcl_potions_potion_splash.png"},
	inventory_image = "mcl_potions_potion_splash.png",
	wield_image = "mcl_potions_potion_splash.png",
	paramtype = "light",
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.25, -0.5, -0.25, 0.25, 0.4, 0.25}
	},
	groups = {vessel=1,dig_immediate=3,attached_node=1},
	sounds = mcl_core.node_sound_mcl_cores(),
})

minetest.register_craft( {
	output = "mcl_potions:potion_splash 5",
	recipe = {
		{ "mcl_core:steel_ingot", "", "mcl_core:steel_ingot" },
		{ "mcl_core:steel_ingot", "", "mcl_core:steel_ingot" },
		{ "", "mcl_core:steel_ingot", "" }
	}
})


-- Make sure we can recycle them

minetest.register_craftitem("mcl_potions:spider_eye_fermented", {
	description = "Fermented Spider Eye",
	inventory_image = "mcl_potions_fermented_spider_eye.png",
})

minetest.register_craft( {
	type = "shapeless",
	output = "mcl_potions:glass_fragments",
	recipe = {
		"mcl_potions:potion_bottle",
		"mcl_potions:potion_bottle",
	},
})

minetest.register_craft( {
	type = "shapeless",
	output = "mcl_potions:glass_fragments",
	recipe = {
		"mcl_potions:potion_drinkable",
		"mcl_potions:potion_drinkable",
	},
})

minetest.register_craft({
	type = "cooking",
	output = "mcl_core:glass",
	recipe = "mcl_potions:spider_eye_fermented",
})

minetest.register_craft( {
	type = "cooking",
	output = "mcl_core:steel_ingot",
	recipe = "mcl_potions:potion_splash",
})

