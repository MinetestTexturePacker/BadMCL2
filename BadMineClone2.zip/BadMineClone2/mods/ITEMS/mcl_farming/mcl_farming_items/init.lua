minetest.register_node("mcl_farming_items:melon", {
	description = "Melon",
	drawtype = "plantlike",
	tiles = {"mcl_farming_melon.png" },
	inventory_image = "mcl_farming_melon.png",
	wield_image = "mcl_farming_melon.png",
	sunlight_propagates = true,
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flammable=2,flower=1,flora=1,attached_node=1,color_white=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = { -0.5, -0.5, -0.5, 0.5, -0.2, 0.5 },
	},
})

minetest.register_node("mcl_farming_items:pumpkin", {
	description = "Pumpkin",
	drawtype = "plantlike",
	tiles = {"mcl_farming_pumpkin.png"},
	inventory_image = "mcl_farming_pumpkin.png",
	wield_image = "mcl_farming_pumpkin.png",
	sunlight_propagates = true,
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flammable=2,flower=1,flora=1,attached_node=1,color_white=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = { -0.5, -0.5, -0.5, 0.5, -0.2, 0.5 },
	},
})

minetest.register_node("mcl_farming_items:potatoes", {
	description = "Potatoes",
	drawtype = "plantlike",
	tiles = {"mcl_farming_potatoes.png"},
	inventory_image = "mcl_farming_potatoes.png",
	wield_image = "mcl_farming_potatoes.png",
	sunlight_propagates = true,
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flammable=2,flower=1,flora=1,attached_node=1,color_white=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = { -0.5, -0.5, -0.5, 0.5, -0.2, 0.5 },
	},
})

minetest.register_node("mcl_farming_items:carrots", {
	description = "Carrots",
	drawtype = "plantlike",
	tiles = {"mcl_farming_carrots.png"},
	inventory_image = "mcl_farming_carrots.png",
	wield_image = "mcl_farming_carrots.png",
	sunlight_propagates = true,
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flammable=2,flower=1,flora=1,attached_node=1,color_white=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = { -0.5, -0.5, -0.5, 0.5, -0.2, 0.5 },
	},
})

minetest.register_craftitem("mcl_farming_items:potato", {
	description = "Potato",
	inventory_image = "mcl_farming_potato.png",
	groups = {food=1},
})

minetest.register_craftitem("mcl_farming_items:potato", {
	description = "Poisonous Potato",
	inventory_image = "mcl_farming_potato_poison.png",
	groups = {food=1},
})

minetest.register_craftitem("mcl_farming_items:potato_baked", {
	description = "Baked Potato",
	inventory_image = "mcl_farming_potato_baked.png",
	groups = {food=1},
})


minetest.register_craftitem("mcl_farming_items:carrot", {
	description = "Carrot",
	inventory_image = "mcl_farming_carrot.png",
	groups = {food=1},
})

minetest.register_craftitem("mcl_farming_items:carrot_gold", {
	description = "Golden Carrot",
	inventory_image = "mcl_farming_carrot_gold.png",
	groups = {food=1},
})

minetest.register_craftitem("mcl_farming_items:melon_slice", {
	description = "Melon Slice",
	inventory_image = "mcl_farming_melon_slice.png",
	groups = {food=1},
})

minetest.register_craftitem("mcl_farming_items:cookie", {
	description = "Cookie",
	inventory_image = "mcl_farming_cookie.png",
	groups = {food=1},
})

minetest.register_craftitem("mcl_farming_items:glistening_melon", {
	description = "Glistening Melon",
	inventory_image = "mcl_farming_melon_speckled.png",
	groups = {food=1},
})

minetest.register_craftitem("mcl_farming_items:mushroom_stew", {
	description = "Mushroom Stew",
	inventory_image = "mcl_farming_mushroom_stew.png",
	groups = {food=1},
})


--mcl_farming_mushroom_stew.png old texture