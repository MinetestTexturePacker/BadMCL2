Mod "Dungeon Loot" [dungeon_loot]
=================================
Copyright (c) 2015 BlockMen <blockmen2015@gmail.com>
and Amoeba <amoeba@iki.fi>

Version: 1.1 alpha


A simple mod that add to dungeons chests that contain some loot.
Configurable in many aspects, see "config.lua" for more details.

In MultiCraft Project this code has been changed:
I changed the drop in a few lines.

License:
~~~~~~~~
Code:
(c) Copyright 2015 BlockMen; modified zlib-License
see "LICENSE.txt" for details.

Media(if not stated differently):
(c) Copyright (2014-2015) BlockMen; CC-BY-SA 3.0


Github:
~~~~~~~
https://github.com/BlockMen/dungeon_loot


Forum:
~~~~~~
https://forum.minetest.net/viewtopic.php?id=13487


Changelog:
~~~~~~~~~~
-
