mcl_creative = {}

mcl_creative.set_creative_formspec = function()

end

minetest.register_on_player_receive_fields(function(player, formname, fields)

end)



-- Form related stuff
mcl_creative.gui_bg = "bgcolor[#080808BB;true]"
mcl_creative.gui_bg_img = "background[5,5;1,1;dialog_creative_active_opaque.png^dialog_creative_active_sel;true]"
mcl_creative.gui_slots = "listcolors[#00000069;#5A5A5A;#141318;#30434C;#FFF]"

function mcl_creative.get_hotbar_bg(x,y)
	local out = ""
	for i=0,7,1 do
		out = out .."image["..x+i..","..y..";1,1;dialog_bg_down.png]"
	end
	return out
end

mcl_creative.gui_survival_form = "size[8,8.5]"..
			mcl_creative.gui_bg..
			mcl_creative.gui_bg_img..
			mcl_creative.gui_slots..
			"list[current_player;main;0,4.25;8,1;]"..
			"list[current_player;main;0,5.5;8,3;8]"..
			"list[current_player;craft;1.75,0.5;3,3;]"..
			"list[current_player;craftpreview;5.75,1.5;1,1;]"..
			"image[4.75,1.5;1,1;dialog_bg_up.png^[transformR270]"..
			mcl_creative.get_hotbar_bg(0,4.25)
