-- Formspecs
mcl_core.gui_suvival_form = mcl_core.gui_survival_form
