-- Place the armor textures here.

-- Formspecs
default.gui_suvival_form = default.gui_survival_form
